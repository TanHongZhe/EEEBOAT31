#ifndef MAGNET_H
#define MAGNET_H
#include <Arduino.h>
#include "Sensor.h"

#define MAG_NUM_READINGS 10
#define VOLT_UPPER 2.9
#define VOLT_LOWER 1.1

class Magnet : public Sensor<String> {
  public:
  Magnet() {
    setCurrentData("N/A");
    setStatus("N/A");
  }
  void setup(const int& analog_in){
    input_pin = analog_in;
  }
  void update(){
    total-=readings[count];
    readings[count]=analogRead(input_pin);
    total += readings[count];
    count++;
    if (count >= MAG_NUM_READINGS ){
      count=0;
    }
    average_voltage=(double)total/MAG_NUM_READINGS*3.3/1023.0;

    if (average_voltage>VOLT_UPPER){
      setCurrentData("Down");
      setLastValidData("Down");
    } else if (average_voltage<VOLT_LOWER){
      setCurrentData("Up");
      setLastValidData("Up");
    } else {
      setCurrentData("None");
    }
    
    setStatus(getCurrentData() +" V: "+String(average_voltage));
  }

  private:
  int readings[MAG_NUM_READINGS]={0};
  int total=0;
  int count=0;
  int input_pin;
  double average_voltage=0;

};
#endif