#ifndef SPECIES_H
#define SPECIES_H
#include <Arduino.h>
#include "Sensor.h"
#define SPECIES_HISTORY_SIZE 10
class Species : public Sensor<String> {
  public:
  Species() {
    setCurrentData("N/A");
    setStatus("N/A");

    for (int i=0;i<SPECIES_HISTORY_SIZE;i++){
      last_valid[i]={"N/A_"+String(i), 0, 0};
    }
  }
  void setup(){
  }
  void update(int infrared_val, int radio_val, String magnetic){
    if (infrared_val >= 447 && infrared_val <= 467 && magnetic == "Down") {
        //setCurrentData("Wibbo");
        //setLastValid()
        pushValid("Wibbo");
    }
    
    // Gribbit: Infrared=N/A, Radio=100Hz, Magnetic=Down  
    else if (radio_val >= 75 && radio_val <= 125 && magnetic == "Down") {
        //setCurrentData("Gribbit");
        pushValid("Gribbit");
    }
    
    // Snorkle: Infrared=293Hz, Radio=N/A, Magnetic=Up
    else if (infrared_val >= 283 && infrared_val <= 303 && magnetic == "Up") {
        //setCurrentData("Snorkle");
        pushValid("Snorkle");
    }
    
    // Zapple: Infrared=N/A, Radio=150Hz, Magnetic=Up
    else if (radio_val >= 125 && radio_val <= 175 && magnetic == "Up") {
        //setCurrentData("Zapple");
        pushValid("Zapple");
    } else {
      setCurrentData("Unknown");

    }
    String tmp_status="Current: "+getCurrentData()+"<br>Last: ";
    uint32_t now = millis();
    for(auto& i : last_valid){
      tmp_status+=String(i.count) + " " + i.str + " "+ String(now-i.time) + " ms ago<br>";
    }
    setStatus(tmp_status);
  
  }
  private:
  void pushValid(String data){
    setCurrentData(data);
    setLastValidData(data);
    // if(last_valid[0].str==data){
    //   last_valid[0].time = getLastValidUpdated();
    // } else {
    //   for (int i=SPECIES_HISTORY_SIZE-1;i>0;i--){
    //     last_valid[i]=last_valid[i-1];
    //   }
    //   last_valid[0]={data, getLastValidUpdated()};
    // }
    
    int tmp_count=1;

    string_time_pair last_valid_tmp[SPECIES_HISTORY_SIZE];
    int j=1;
    for (int i=0;i<SPECIES_HISTORY_SIZE;i++){
      if (j<SPECIES_HISTORY_SIZE){
        last_valid_tmp[j]=last_valid[i];
      }
      if (last_valid[i].str==data && (getLastUpdated()-last_valid[i].time)<5000 ){
        tmp_count+=last_valid[i].count;
        last_valid[i]={"----", 0, 0};
      } else {
        j++;
      }
    }
    last_valid[0]={data, getLastValidUpdated(), tmp_count};
    for (int i=1;i<SPECIES_HISTORY_SIZE;i++){
      last_valid[i]=last_valid_tmp[i];
    }
  }
  struct string_time_pair {
    String str;
    uint32_t time;
    int count;
  };
  string_time_pair last_valid[SPECIES_HISTORY_SIZE];;
  int last_valid_count = 0;

};
#endif