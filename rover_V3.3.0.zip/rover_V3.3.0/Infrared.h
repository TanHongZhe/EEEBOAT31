#ifndef IR_H
#define IR_H
#include <Arduino.h>
#include "Sensor.h"

//#define NUM_READINGS 10
#define MIN_FREQ_1 283
#define MAX_FREQ_1 303
#define MIN_FREQ_2 447
#define MAX_FREQ_2 467

class Infrared : public Sensor<double> {
  public:
  Infrared(){
    setCurrentData(0);
    setStatus("N/A");
  }
  void setup(const int& pin, voidFuncPtr callback){
    input_pin = pin;
    pinMode(input_pin, INPUT_PULLDOWN);
    attachInterrupt(digitalPinToInterrupt(input_pin), callback, RISING);
  }
  void onPulse(){
    //Serial.print("IR_Int");
    uint64_t now = micros();
    interval = now - last_pulse;
    last_pulse=now;
    new_pulse=true;
  }
  void update(){
    if (new_pulse) {
      noInterrupts();
      uint32_t tmp_interval=interval;
      //new_pulse=false;
      interrupts();

      double frequency = 1000000.0 / interval;
      setCurrentData(frequency);
      // if (frequency >= MIN_FREQ && frequency <= MAX_FREQ) {
      //   setStatus(String(frequency) + " Hz");
      // } else {
      //   setStatus("out of range: " + String(frequency) + " Hz");
      // }
      if(frequency >= MIN_FREQ_1 && frequency <= MAX_FREQ_1) {
        //setStatus("Signal within ±10 range (293Hz target): " + String(frequency, 2) + "Hz");
        //last_valid = frequency;
        setLastValidData(293);
      }
      // Check for 457 Hz (±10 Hz range: 447-467)
      else if(frequency >= MIN_FREQ_2 && frequency <= MAX_FREQ_2) {
        //setStatus("Signal within ±10 range (457Hz target): " + String(frequency, 2) + "Hz");
        //last_valid = frequency;
        setLastValidData(457);
      }
      
    }// else {
    //   uint32_t diff = millis()-getLastUpdated();
    //   setStatus(String(getCurrentData(),2)+ " " + String(diff) + "ms ago");
    // }
    
    uint32_t now = millis();
    if (now-getStatusLastUpdated()>10 || new_pulse){
      double frequency = getCurrentData();
      setStatus(String(frequency, 2) + "Hz, "+ String(now-getLastUpdated())+" ms ago<br> last valid: "+String(getLastValidData())+" "+String(now-getLastValidUpdated())+" ms ago");
    }
    new_pulse=false;
  }
  

  private:
  uint64_t interval=0;
  //int readings[NUM_READINGS]={0};
  //uint32_t total=0;
  int count=0;
  int input_pin;
  uint64_t last_pulse=0;
  //int last_valid=0;
  bool new_pulse=false;
};
#endif