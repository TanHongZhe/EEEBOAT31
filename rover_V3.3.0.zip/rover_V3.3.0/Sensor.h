
#ifndef SENSOR_H
#define SENSOR_H
#include <Arduino.h>

template <typename T>
class Sensor {
  public:
  Sensor(){

  }
  uint32_t getLastUpdated(){
    return last_updated;
  }
  T getCurrentData(){
    return current_data;
  }
  uint32_t getLastValidUpdated(){
    return last_valid_updated;
  }
  T getLastValidData(){
    return last_valid_data;
  }
  String getStatus(){
    return status;
  }
  uint32_t getStatusLastUpdated(){
    return status_last_updated;
  }
  virtual void setup(){};
  virtual void update(){};
  
  
  private:
  uint32_t last_updated=0;
  T current_data;
  uint32_t last_valid_updated=0;
  uint32_t status_last_updated=0;
  T last_valid_data;
  String status;
  protected:
  void setCurrentData(T data){
    last_updated=millis();
    current_data=data;
  }
  void setLastValidData(T data){
    last_valid_updated=millis();
    last_valid_data=data;
  }
  void setStatus(String new_status){
    status_last_updated=millis();
    status=new_status;
  }
};
#endif