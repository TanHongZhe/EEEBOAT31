#ifndef MOTORC_H
#define MOTORC_H
#include <Arduino.h>
#define MOTOR_OFFSET 40
// const int motorPWM1 = 3;   // PWM pin for motor 1
// const int motorPWM2 = 12;  // PWM pin for motor 2
// const int motorDir1 = 8;   // Direction pin for motor 1
// const int motorDir2 = 9;   // Direction pin for motor 2

class MotorControl {
  public:
  MotorControl(){

  }
  void setup(int PWM1, int PWM2, int Dir1, int Dir2){
    motorPWM1 = PWM1;   // PWM pin for motor 1
    motorPWM2 = PWM2;  // PWM pin for motor 2
    motorDir1 = Dir1;   // Direction pin for motor 1
    motorDir2 = Dir2;   // Direction pin for motor 2
      // Initialize motor pins
    pinMode(motorPWM1, OUTPUT);
    pinMode(motorPWM2, OUTPUT);
    pinMode(motorDir1, OUTPUT);
    pinMode(motorDir2, OUTPUT);
    init=true;
    // Start with motors stopped
    update(0, 0);
  };
  void update(int J_x, int J_y){
    if (!init){
      return;
    }
    float x = (joystickCurve(J_x)*254);
    float y = (joystickCurve(J_y)*254);
    int motor_offset=MOTOR_OFFSET;
    float L_pwm = (y+x);
    float R_pwm = (y-x);
    if (L_pwm*R_pwm<0){
      motor_offset*=2;
    }
    if (L_pwm>1){
      L_pwm=L_pwm+motor_offset;
    } else if(L_pwm<-1){
      L_pwm=L_pwm-motor_offset;
    }

    if (R_pwm>1){
      R_pwm=R_pwm+motor_offset;
    } else if(R_pwm<-1){
      R_pwm=R_pwm-motor_offset;
    }

    if (L_pwm > 254 || L_pwm < -254){
      float k = abs(L_pwm/254);
      L_pwm = L_pwm/k;
      R_pwm = R_pwm/k;
    } 
    if (R_pwm > 254 || R_pwm < -254){
      float k = abs(R_pwm/254);
      L_pwm = L_pwm/k;
      R_pwm = R_pwm/k;
    }

    Serial.print(", L_pwm: "); 
  Serial.print(L_pwm);
  Serial.print(", R_pwm: ");
  Serial.println(R_pwm);


    // Calculate PWM values for each motor
    if (L_pwm > 0) {
        analogWrite(motorPWM1, L_pwm); // Forward for motor 1
        //Serial.print("Dir1 Low");
        digitalWrite(motorDir1, LOW); // Forward
    } else {
        analogWrite(motorPWM1, -L_pwm); // Backward for motor 1
        //Serial.print("Dir1 High");
        digitalWrite(motorDir1, HIGH); // Backward
    }

    if (R_pwm > 0) {
        analogWrite(motorPWM2, R_pwm); // Forward for motor 2
        //Serial.println(" Dir2 Low");
        digitalWrite(motorDir2, LOW); // Forward
    } else {
        analogWrite(motorPWM2, -R_pwm); // Backward for motor 2
        //Serial.println(" Dir2 High");
        digitalWrite(motorDir2, HIGH); // Backward
    }

  };
  
  
  private:

  int motorPWM1;   // PWM pin for motor 1
  int motorPWM2;  // PWM pin for motor 2
  int motorDir1;   // Direction pin for motor 1
  int motorDir2;   // Direction pin for motor 2
  bool init=false;

  float joystickCurve(float input) {
    float p = input/255;
    //Serial.print(" Mag= ");
    //Serial.print(p);
    // float ans = p; // LINEAR MODE
    float ans = p * p * p; // CUBIX MODE
    //float ans = sin((3.1415/2)*p); // SINUSOIDAL MODE
    //float ans = asin(p)*2/3.1415;


    return ans; // Cubic curve for smoother control
  }
};
#endif