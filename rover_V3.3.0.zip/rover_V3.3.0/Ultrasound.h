#ifndef ULTRASOUND_H
#define ULTRASOUND_H
#define ULTRASOUND_HISTORY_SIZE 10
#include <Arduino.h>
#include <Servo.h>
#include "Sensor.h"

class Ultrasound : public Sensor<String> {
  public:
  Ultrasound() {
    setCurrentData("N/A");
    for (int i=0;i<ULTRASOUND_HISTORY_SIZE;i++){
      last_valid[i]={"N/A"+String(i), 0, 0};
    }
    
  }
  void setup(const int& servo_pin_in){
    servo_pin = servo_pin_in;
    ultrasound_servo.attach(servo_pin);
    Serial1.begin(600);
  }
  void update(){
    uint32_t start = millis();
    while(Serial1.available() && millis()-start<30){
      char c=Serial1.read();
      //Serial.println(c);
      if (c=='#'){
        count=0;
        current_name_valid=true;
      } else if (count==4 || !is_valid_char(c)){
        current_name_valid=false;
      } else if(current_name_valid){
        name_temp[count]=c;
      }
      count++;
      if (current_name_valid && count==4){
        pushValid(name_temp);
      }
    }
    //Serial.println("Diff");
    //uint32_t diff = millis()-getLastUpdated();
    //setStatus(getCurrentData()+ " " + String(diff) + "ms ago");
    String tmp_status="Current: "+getCurrentData()+"<br>Last: ";
    uint32_t now = millis();
    for(auto& i : last_valid){
      tmp_status+=String(i.count) + " " + i.str + " "+ String(now-i.time) + " ms ago<br>";
    }
    setStatus(tmp_status);
    
    double servo_diff = micros()-servo_timestamp;
    if (servo_diff>1500){
      ultrasound_servo_pos+=ultrasound_servo_step;//*servo_diff/1500.0;
      if ((ultrasound_servo_pos<=1250 || ultrasound_servo_pos>=1550)){
        ultrasound_servo_step*=-1;

      }
      ultrasound_servo.writeMicroseconds(ultrasound_servo_pos);
      servo_timestamp=micros();
    }

  }
  bool is_valid_char(char c){
  String valid = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  if (valid.indexOf(c)<0){
    return false;
  }
  return true;
}
  
  private:
  int count=0;
  bool current_name_valid=false;
  String name_temp = "####";
  int servo_pin;
  int ultrasound_servo_pos=1500;
  int ultrasound_servo_step=3;
  uint32_t servo_timestamp=0;
  Servo ultrasound_servo;

  void pushValid(String data){
    setCurrentData(data);
    setLastValidData(data);
    int tmp_count=1;

    string_time_pair last_valid_tmp[ULTRASOUND_HISTORY_SIZE];
    int j=1;
    for (int i=0;i<ULTRASOUND_HISTORY_SIZE;i++){
      if (j<ULTRASOUND_HISTORY_SIZE){
        last_valid_tmp[j]=last_valid[i];
      }
      if (last_valid[i].str==data && (getLastUpdated()-last_valid[i].time)<5000 ){
        tmp_count+=last_valid[i].count;
        last_valid[i]={"----", 0, 0};
      } else {
        j++;
      }
    }
    last_valid[0]={data, getLastValidUpdated(), tmp_count};
    for (int i=1;i<ULTRASOUND_HISTORY_SIZE;i++){
      last_valid[i]=last_valid_tmp[i];
    }
  }
  struct string_time_pair {
    String str;
    uint32_t time;
    int count;
  };
  string_time_pair last_valid[ULTRASOUND_HISTORY_SIZE];
  int last_valid_count = 0;

};
#endif