#ifndef WEB_H
#define WEB_H
#include <Arduino.h>
#include <WiFi101.h>
#include "Sensor.h"
#define CLIENT_TIMEOUT_MS 3000
#define MOTOR_TIMEOUT_MS 150
// WiFi credentials

char ssid[] = "G31";
char pass[] = "group31a";

struct coordinate{
  int x;
  int y;
};

class Web : public Sensor<coordinate> {
  public:
  Web(): server(80){

  }

  void setup(){
    while(WiFi.status() == WL_NO_SHIELD) {
      Serial.println("WiFi shield not present");
      delay(500);
    }
    // Connect to WiFi
    connectToWiFi();
    
    // Start the web server
    server.begin();
    Serial.print("HTTP server started at: ");
    Serial.println(WiFi.localIP());
    Serial.println("Ready to receive joystick commands!");
  };

  void update(String ultrasound_status, String infrared_status, String radio_status, String magnet_status, String species_value){
    WiFiClient client = server.available();
    if (client) {
      //Serial.println("New client connected"); AVT VERBOSE
      String request = "";
      uint64_t client_connect_start = millis();
      // Read the HTTP request with timeout
      while (client.connected() && (millis() - client_connect_start < CLIENT_TIMEOUT_MS)) {
        if (client.available()) {
          String line = client.readStringUntil('\r');
          if (line.startsWith("GET")) {
            request = line;
            break;
          }
          if (millis()-getLastUpdated()>=MOTOR_TIMEOUT_MS){
            setCurrentData({0,0});
          }
        }
        delay(1); // Small delay to prevent tight loop
      }


      // Check if we got a valid request
      if (request.length() > 0) {
        while (client.available()){
          client.read();
        }
        // Process the command
        processCommand(request, client, ultrasound_status, infrared_status, radio_status, magnet_status, species_value);
      } else {
        Serial.println("Client timeout or no valid request received");
      }

      // if (millis()-getLastUpdated()>=MOTOR_TIMEOUT_MS){
      //   setCurrentData({0,0});
      // }
      // Close the connection
      client.flush();
      client.stop();
      //Serial.println("Client disconnected"); AVT VERBOSE
    }

    if (millis() - lastCheck > 10000) {
      if (WiFi.status() != WL_CONNECTED) {
        Serial.println("WiFi disconnected! Resetting coordinates...");
        setCurrentData({0,0});
        
        // Reconnect WiFi (this will restart server automatically)
        connectToWiFi();
        
        // Restart server after successful reconnection
        if (WiFi.status() == WL_CONNECTED) {
          server.begin();
          Serial.println("Web server restarted on new IP!");
        }
      }
      lastCheck = millis();
    }

    // Send periodic keep-alive to maintain WiFi connection
    
    if (millis() - lastKeepAlive > 20000) { // Every 20 seconds
      if (WiFi.status() == WL_CONNECTED) {
        WiFi.ping(WiFi.gatewayIP()); // Ping the router
        Serial.println("WiFi keep-alive ping sent");
      }
      lastKeepAlive = millis();
    }
  }

  private:
  
  int wifi_status = WL_IDLE_STATUS;
  uint64_t lastCheck = 0;
  uint64_t lastKeepAlive = 0;
  WiFiServer server;
  bool isActivelyControlling;
  void handleHeartbeat(String request, WiFiClient client) {
    // Heartbeat keeps connection alive but doesn't reset the safety timeout
    // This allows us to distinguish between active user input and keep-alive messages
    
    client.println("HTTP/1.1 200 OK");
    client.println("Content-Type: text/plain");
    client.println("Connection: close");
    client.println();
    client.println("HEARTBEAT_OK");
    
    // Note: We DON'T update lastCommandReceived here - only real joystick commands do that
    Serial.println("Heartbeat received (no timeout reset)");
  }
  void connectToWiFi() {
    Serial.print("Connecting to WiFi: ");
    Serial.println(ssid);
    
    wifi_status = WiFi.begin(ssid, pass);
    
    // Wait for connection
    int attempts = 0;
    while (wifi_status != WL_CONNECTED && attempts < 2000) {
      delay(500);
      Serial.print(".");
      WiFi.begin(ssid, pass);
      wifi_status = WiFi.status();
      attempts++;
    }
      
    if (wifi_status == WL_CONNECTED) {
      Serial.println();
      Serial.println("✓ WiFi connected!");
      
      // Get and print IP address
      IPAddress ip = WiFi.localIP();
      Serial.print("IP address: ");
      Serial.println(ip);
      
      Serial.print("Signal strength: ");
      Serial.print(WiFi.RSSI());
      Serial.println(" dBm");
      
      // Restart web server after reconnection
      delay(100);      // Brief delay
      server.begin();  // Start fresh server
      Serial.println("Web server restarted on new IP!");
      
    } else {
      Serial.println("\n✗ Failed to connect to WiFi!");
    }
  }
  void processCommand(String request, WiFiClient client, String ultrasound_status, String infrared_status, String radio_status, String magnet_status, String species_value) {
    //Serial.print("Processing command: "); AVT VERBOSE
    //Serial.println(request); AVT VERBOSE
    
    // Parse the request
    if (request.indexOf("GET / ") >= 0) {
      // Serve main page with joystick
      sendJoystickPage(client);
    } else if (request.indexOf("GET /joystick") >= 0) {
      // Handle joystick coordinate updates - now just updates variables, motor control happens in main loop
      if (isActivelyControlling){
        handleJoystickUpdate(request, client);
      }
    } else if (request.indexOf("GET /start_control") >= 0) {
      // User started actively controlling
      isActivelyControlling = true;
      //lastCommandReceived = millis();
      client.println("HTTP/1.1 200 OK");
      client.println("Content-Type: text/plain");
      client.println("Connection: close");
      client.println();
      client.println("CONTROL_STARTED");
      Serial.println("🎮 Active control started");
    } else if (request.indexOf("GET /stop_control") >= 0) {
      // User stopped actively controlling
      isActivelyControlling = false;
      setCurrentData({0,0});
      //lastCommandReceived = millis();
      client.println("HTTP/1.1 200 OK");
      client.println("Content-Type: text/plain");
      client.println("Connection: close");
      client.println();
      client.println("CONTROL_STOPPED");
      Serial.println("🛑 Active control stopped");
    } else if (request.indexOf("GET /heartbeat") >= 0) {
      // Handle heartbeat - keeps connection alive but doesn't reset timeout
      handleHeartbeat(request, client);
    } else if (request.indexOf("GET /getcoordinates") >= 0) {
      // Send current coordinates as JSON
      client.println("HTTP/1.1 200 OK");
      client.println("Content-Type: application/json");
      client.println("Connection: close");
      client.println();
      client.print("{\"x\":");
      client.print(getCurrentData().x);
      client.print(",\"y\":");
      client.print(getCurrentData().y);
      client.println("}");
    } else if (request.indexOf("GET /getdata") >= 0) {
      // Send all sensor data as JSON
      client.println("HTTP/1.1 200 OK");
      client.println("Content-Type: application/json");
      client.println("Connection: close");
      client.println();
      
      client.print("{\"name\":\"");
      client.print(ultrasound_status);
      client.print("\",\"species\":\"");
      client.print(species_value);
      client.print("\",\"infrared\":\"");
      client.print(infrared_status);
      client.print("\",\"radio\":\"");
      client.print(radio_status);
      client.print("\",\"magnetic\":\"");
      client.print(magnet_status);
      client.println("\"}");  
    } else {
      // 404 Not Found
      client.println("HTTP/1.1 404 Not Found");
      client.println("Content-Type: text/plain");
      client.println("Connection: close");
      client.println();
      client.println("Route not found");
    }
  }
  void handleJoystickUpdate(String request, WiFiClient client) {
    // Extract X and Y values from URL: /joystick?x=123&y=456
    int xStart = request.indexOf("x=");
    int yStart = request.indexOf("y=");
    
    if (xStart > 0 && yStart > 0) {
      xStart += 2; // Skip "x="
      yStart += 2; // Skip "y="
      
      // Find end of X value
      int xEnd = request.indexOf("&", xStart);
      if (xEnd < 0) xEnd = request.indexOf(" ", xStart);
      
      // Find end of Y value  
      int yEnd = request.indexOf(" ", yStart);
      if (yEnd < 0) yEnd = request.indexOf("&", yStart);
      if (yEnd < 0) yEnd = request.length();
      
      // Extract coordinate strings
      String xStr = request.substring(xStart, xEnd);
      String yStr = request.substring(yStart, yEnd);
      
      // Convert to integers
      int newX = xStr.toInt();
      int newY = yStr.toInt();
      
      // Validate range (-255 to 255)
      if (newX >= -255 && newX <= 255 && newY >= -255 && newY <= 255) {
        setCurrentData({newX, newY});
        
        // // Print coordinate update - motor control happens in main loop every 30ms
        // Serial.print("JOYSTICK UPDATE: X=");
        // Serial.print(newX);
        // Serial.print(", Y=");
        // Serial.print(newY);
        // Serial.println(" (Motor update in next 30ms cycle)");
        
        // Send success response
        client.println("HTTP/1.1 200 OK");
        client.println("Content-Type: text/plain");
        client.println("Connection: close");
        client.println();
        client.println("OK");
      } else {
        Serial.println("❌ Invalid coordinate range received");
        client.println("HTTP/1.1 400 Bad Request");
        client.println("Content-Type: text/plain");
        client.println("Connection: close");
        client.println();
        client.println("Invalid coordinates");
      }
    } else {
      Serial.println("❌ Malformed joystick request");
      client.println("HTTP/1.1 400 Bad Request");
      client.println("Content-Type: text/plain");
      client.println("Connection: close");
      client.println();
      client.println("Missing coordinates");
    }
  }

void sendJoystickPage(WiFiClient client) {
  // Get IP address as string
  IPAddress ip = WiFi.localIP();
  
  Serial.println("Sending joystick page...");
  
  client.println("HTTP/1.1 200 OK");
  client.println("Content-Type: text/html");
  client.println("Connection: close");
  client.println();
  
  // Send HTML page with WiFi joystick
  client.println(F("<!DOCTYPE HTML>"));
  client.println(F("<html>"));
  client.println(F("<head>"));
  client.println(F("<title>WiFi Joystick Controller</title>"));
  client.println(F("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"));
  client.println(F("<style>"));
  
  // CSS Styles
  client.println(F("* {"));
  client.println(F("  box-sizing: border-box;"));
  client.println(F("}"));
  
  client.println(F("html, body {"));
  client.println(F("  margin: 0;"));
  client.println(F("  padding: 0;"));
  client.println(F("  height: 100%;"));
  client.println(F("  font-family: Arial, sans-serif;"));
  client.println(F("  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);"));
  client.println(F("  overflow: hidden;"));
  client.println(F("}"));
  
  client.println(F(".app-container {"));
  client.println(F("  display: flex;"));
  client.println(F("  height: 100vh;"));
  client.println(F("  width: 100vw;"));
  client.println(F("}"));
  
  // Fixed joystick section on the left
  client.println(F(".joystick-section {"));
  client.println(F("  flex: 0 0 350px;"));
  client.println(F("  background-color: white;"));
  client.println(F("  display: flex;"));
  client.println(F("  flex-direction: column;"));
  client.println(F("  align-items: center;"));
  client.println(F("  justify-content: center;"));
  client.println(F("  padding: 20px;"));
  client.println(F("  box-shadow: 2px 0 10px rgba(0,0,0,0.1);"));
  client.println(F("  position: relative;"));
  client.println(F("  z-index: 10;"));
  client.println(F("}"));
  
  // Scrollable data section on the right
  client.println(F(".data-section {"));
  client.println(F("  flex: 1;"));
  client.println(F("  overflow-y: auto;"));
  client.println(F("  padding: 20px;"));
  client.println(F("  background: transparent;"));
  client.println(F("}"));
  
  client.println(F(".joystick-container {"));
  client.println(F("  position: relative;"));
  client.println(F("  width: 220px;"));
  client.println(F("  height: 220px;"));
  client.println(F("  margin: 20px auto;"));
  client.println(F("  background: #f0f0f0;"));
  client.println(F("  border-radius: 50%;"));
  client.println(F("  border: 3px solid #ccc;"));
  client.println(F("  box-shadow: inset 0 4px 10px rgba(0,0,0,0.1);"));
  client.println(F("  flex-shrink: 0;"));
  client.println(F("}"));
  
  client.println(F(".joystick-knob {"));
  client.println(F("  position: absolute;"));
  client.println(F("  width: 60px;"));
  client.println(F("  height: 60px;"));
  client.println(F("  background: linear-gradient(135deg, #28a745 0%, #20c997 100%);"));
  client.println(F("  border-radius: 50%;"));
  client.println(F("  cursor: pointer;"));
  client.println(F("  box-shadow: 0 4px 15px rgba(0,0,0,0.3);"));
  client.println(F("  top: 50%;"));
  client.println(F("  left: 50%;"));
  client.println(F("  transform: translate(-50%, -50%);"));
  client.println(F("  transition: box-shadow 0.2s ease;"));
  client.println(F("  border: 3px solid white;"));
  client.println(F("  z-index: 10;"));
  client.println(F("  aspect-ratio: 1 / 1;"));
  client.println(F("}"));
  
  client.println(F(".coordinates-display {"));
  client.println(F("  font-size: 14px;"));
  client.println(F("  font-weight: bold;"));
  client.println(F("  margin: 20px 0;"));
  client.println(F("  padding: 15px;"));
  client.println(F("  background: #f8f9fa;"));
  client.println(F("  border-radius: 15px;"));
  client.println(F("  width: 250px;"));
  client.println(F("  text-align: center;"));
  client.println(F("}"));
  
  client.println(F(".reset-btn {"));
  client.println(F("  background: #dc3545;"));
  client.println(F("  color: white;"));
  client.println(F("  border: none;"));
  client.println(F("  padding: 15px 30px;"));
  client.println(F("  border-radius: 10px;"));
  client.println(F("  font-size: 16px;"));
  client.println(F("  font-weight: bold;"));
  client.println(F("  cursor: pointer;"));
  client.println(F("  margin-top: 20px;"));
  client.println(F("  transition: all 0.3s ease;"));
  client.println(F("  width: 250px;"));
  client.println(F("}"));
  
  client.println(F(".reset-btn:hover {"));
  client.println(F("  background: #c82333;"));
  client.println(F("  transform: translateY(-2px);"));
  client.println(F("}"));
  
  client.println(F(".data-card {"));
  client.println(F("  background-color: white;"));
  client.println(F("  margin-bottom: 20px;"));
  client.println(F("  padding: 25px;"));
  client.println(F("  border-radius: 20px;"));
  client.println(F("  box-shadow: 0 8px 25px rgba(0,0,0,0.15);"));
  client.println(F("  max-width: 600px;"));
  client.println(F("}"));
  
  client.println(F(".data-card h3 {"));
  client.println(F("  margin-top: 0;"));
  client.println(F("  color: #333;"));
  client.println(F("  text-align: center;"));
  client.println(F("  margin-bottom: 25px;"));
  client.println(F("  font-size: 24px;"));
  client.println(F("}"));
  
  client.println(F(".data-item {"));
  client.println(F("  display: flex;"));
  client.println(F("  justify-content: space-between;"));
  client.println(F("  align-items: center;"));
  client.println(F("  margin: 15px 0;"));
  client.println(F("  padding: 20px;"));
  client.println(F("  background: #f8f9fa;"));
  client.println(F("  border-radius: 12px;"));
  client.println(F("  box-shadow: 0 2px 8px rgba(0,0,0,0.08);"));
  client.println(F("}"));
  
  client.println(F(".data-label {"));
  client.println(F("  font-weight: bold;"));
  client.println(F("  color: #333;"));
  client.println(F("  font-size: 14px;"));
  client.println(F("}"));
  
  client.println(F(".data-value {"));
  client.println(F("  color: #007bff;"));
  client.println(F("  font-family: monospace;"));
  client.println(F("  font-size: 16px;"));
  client.println(F("  font-weight: bold;"));
  client.println(F("}"));
  
  client.println(F(".status-card {"));
  client.println(F("  background-color: white;"));
  client.println(F("  padding: 25px;"));
  client.println(F("  border-radius: 20px;"));
  client.println(F("  box-shadow: 0 8px 25px rgba(0,0,0,0.15);"));
  client.println(F("  text-align: center;"));
  client.println(F("  max-width: 600px;"));
  client.println(F("  margin-bottom: 20px;"));
  client.println(F("}"));
  
  client.println(F(".status-card h3 {"));
  client.println(F("  color: #28a745;"));
  client.println(F("  margin-top: 0;"));
  client.println(F("  margin-bottom: 15px;"));
  client.println(F("}"));
  
  client.println(F(".ip-display {"));
  client.println(F("  font-family: monospace;"));
  client.println(F("  font-size: 18px;"));
  client.println(F("  color: #007bff;"));
  client.println(F("  font-weight: bold;"));
  client.println(F("  margin: 10px 0;"));
  client.println(F("}"));
  
  // Mobile responsive adjustments
  client.println(F("@media (max-width: 768px) {"));
  client.println(F("  .app-container {"));
  client.println(F("    flex-direction: column;"));
  client.println(F("    overflow-y: auto;"));
  client.println(F("  }"));
  client.println(F("  .joystick-section {"));
  client.println(F("    flex: 0 0 auto;"));
  client.println(F("    width: 100%;"));
  client.println(F("    padding: 15px;"));
  client.println(F("  }"));
  client.println(F("  .joystick-container {"));
  client.println(F("    width: 200px;"));
  client.println(F("    height: 200px;"));
  client.println(F("  }"));
  client.println(F("  .data-section {"));
  client.println(F("    flex: 1;"));
  client.println(F("    overflow-y: visible;"));
  client.println(F("    padding: 15px;"));
  client.println(F("  }"));
  client.println(F("  .coordinates-display,"));
  client.println(F("  .reset-btn {"));
  client.println(F("    width: 200px;"));
  client.println(F("  }"));
  client.println(F("  .data-card {"));
  client.println(F("    margin-left: auto;"));
  client.println(F("    margin-right: auto;"));
  client.println(F("  }"));
  client.println(F("}"));
  
  // Custom scrollbar for webkit browsers
  client.println(F(".data-section::-webkit-scrollbar {"));
  client.println(F("  width: 8px;"));
  client.println(F("}"));
  
  client.println(F(".data-section::-webkit-scrollbar-track {"));
  client.println(F("  background: rgba(255,255,255,0.1);"));
  client.println(F("  border-radius: 4px;"));
  client.println(F("}"));
  
  client.println(F(".data-section::-webkit-scrollbar-thumb {"));
  client.println(F("  background: rgba(255,255,255,0.3);"));
  client.println(F("  border-radius: 4px;"));
  client.println(F("}"));
  
  client.println(F(".data-section::-webkit-scrollbar-thumb:hover {"));
  client.println(F("  background: rgba(255,255,255,0.5);"));
  client.println(F("}"));
  
  client.println(F("</style>"));
  client.println(F("</head>"));
  client.println(F("<body>"));
  
  // HTML Structure
  client.println(F("<div class=\"app-container\">"));
  
  // Fixed Joystick Section (Left Side)
  client.println(F("<div class=\"joystick-section\">"));
  client.println(F("<div class=\"joystick-container\" id=\"joystickContainer\">"));
  client.println(F("<div class=\"joystick-knob\" id=\"joystickKnob\"></div>"));
  client.println(F("</div>"));
  
  client.println(F("<div class=\"coordinates-display\">"));
  client.println(F("X: <span id=\"xValue\">0</span>, Y: <span id=\"yValue\">0</span>"));
  client.println(F("</div>"));
  
  client.println(F("<button class=\"reset-btn\" onclick=\"resetJoystick()\">Reset to Center</button>"));
  client.println(F("</div>"));
  
  // Scrollable Data Section (Right Side)
  client.println(F("<div class=\"data-section\">"));
  
  // Sensor Data Card (no title, simplified)
  client.println(F("<div class=\"data-card\">"));
  client.println(F("<div class=\"data-item\">"));
  client.println(F("<span class=\"data-label\">Name:</span>"));
  client.println(F("<span class=\"data-value\" id=\"nameValue\">Loading...</span>"));
  client.println(F("</div>"));
  client.println(F("<div class=\"data-item\">"));
  client.println(F("<span class=\"data-label\">Species:</span>"));
  client.println(F("<span class=\"data-value\" id=\"speciesValue\">Loading...</span>"));
  client.println(F("</div>"));
  client.println(F("<div class=\"data-item\">"));
  client.println(F("<span class=\"data-label\">Infrared:</span>"));
  client.println(F("<span class=\"data-value\" id=\"infraredValue\">Loading...</span>"));
  client.println(F("</div>"));
  client.println(F("<div class=\"data-item\">"));
  client.println(F("<span class=\"data-label\">Radio:</span>"));
  client.println(F("<span class=\"data-value\" id=\"radioValue\">Loading...</span>"));
  client.println(F("</div>"));
  client.println(F("<div class=\"data-item\">"));
  client.println(F("<span class=\"data-label\">Magnetic:</span>"));
  client.println(F("<span class=\"data-value\" id=\"magneticValue\">Loading...</span>"));
  client.println(F("</div>"));
  client.println(F("</div>"));
  
  client.println(F("</div>"));
  client.println(F("</div>"));
  
  // JavaScript
  client.println(F("<script>"));
  client.println(F("const joystickContainer = document.getElementById('joystickContainer');"));
  client.println(F("const joystickKnob = document.getElementById('joystickKnob');"));
  client.println(F("const xValueDisplay = document.getElementById('xValue');"));
  client.println(F("const yValueDisplay = document.getElementById('yValue');"));
  client.println(F("let isDragging = false;"));
  client.println(F("let containerRect, centerX, centerY, maxRadius;"));
  client.println(F("let lastSentTime = 0;"));
  client.println(F("let currentX = 0, currentY = 0;"));
  client.println(F("let heartbeatInterval;"));
  client.println(F("let commandCount = 0;"));
  client.println(F("let sessionStartTime = Date.now();"));
  
  client.println(F("function initJoystick() {"));
  client.println(F("  containerRect = joystickContainer.getBoundingClientRect();"));
  client.println(F("  centerX = containerRect.width / 2;"));
  client.println(F("  centerY = containerRect.height / 2;"));
  client.println(F("  maxRadius = (containerRect.width / 2) - 30;"));
  client.println(F("}"));
  
  client.println(F("function sendCoordinates(x, y) {"));
  client.println(F("  const now = Date.now();"));
  client.println(F("  if (now - lastSentTime > 50) {"));
  client.println(F("    fetch('/joystick?x=' + x + '&y=' + y)"));
  client.println(F("      .catch(error => console.error('Error:', error));"));
  client.println(F("    lastSentTime = now;"));
  client.println(F("    commandCount++;"));
  client.println(F("    document.getElementById('commandCount').textContent = commandCount;"));
  client.println(F("  }"));
  client.println(F("}"));
  
  client.println(F("function updateSensorData() {"));
  client.println(F("  fetch('/getdata')"));
  client.println(F("    .then(response => response.json())"));
  client.println(F("    .then(data => {"));
  client.println(F("      document.getElementById('nameValue').innerHTML = data.name;"));
  client.println(F("      document.getElementById('speciesValue').innerHTML = data.species;"));
  client.println(F("      document.getElementById('infraredValue').innerHTML = data.infrared;"));
  client.println(F("      document.getElementById('radioValue').innerHTML = data.radio;"));
  client.println(F("      document.getElementById('magneticValue').innerHTML = data.magnetic;"));
  client.println(F("    })"));
  client.println(F("    .catch(error => console.error('Error fetching sensor data:', error));"));
  client.println(F("}"));
  
  client.println(F("function updateJoystick(clientX, clientY) {"));
  client.println(F("  if (!isDragging) {sendCoordinates(0, 0);return;}"));
  client.println(F("  const relativeX = clientX - containerRect.left - centerX;"));
  client.println(F("  const relativeY = clientY - containerRect.top - centerY;"));
  client.println(F("  const distance = Math.sqrt(relativeX * relativeX + relativeY * relativeY);"));
  client.println(F("  let finalX = relativeX, finalY = relativeY;"));
  client.println(F("  if (distance > maxRadius) {"));
  client.println(F("    const angle = Math.atan2(relativeY, relativeX);"));
  client.println(F("    finalX = Math.cos(angle) * maxRadius;"));
  client.println(F("    finalY = Math.sin(angle) * maxRadius;"));
  client.println(F("  }"));
  client.println(F("  joystickKnob.style.left = (centerX + finalX) + 'px';"));
  client.println(F("  joystickKnob.style.top = (centerY + finalY) + 'px';"));
  client.println(F("  const xCoord = Math.round((finalX / maxRadius) * 254);"));
  client.println(F("  const yCoord = Math.round((-finalY / maxRadius) * 254);"));
  client.println(F("  xValueDisplay.textContent = xCoord;"));
  client.println(F("  yValueDisplay.textContent = yCoord;"));
  client.println(F("  sendCoordinates(xCoord, yCoord);"));
  client.println(F("}"));
  
  client.println(F("function resetJoystick() {"));
  client.println(F("  joystickKnob.style.left = '50%';"));
  client.println(F("  joystickKnob.style.top = '50%';"));
  client.println(F("  joystickKnob.style.transform = 'translate(-50%, -50%)';"));
  client.println(F("  xValueDisplay.textContent = '0';"));
  client.println(F("  yValueDisplay.textContent = '0';"));
  client.println(F("  isDragging = false;"));
  client.println(F("  sendCoordinates(0, 0);"));
  client.println(F("}"));
  
  // Mouse Events
  client.println(F("joystickKnob.addEventListener('mousedown', function(e) {"));
  client.println(F("  isDragging = true; initJoystick(); e.preventDefault();"));
  client.println(F("  fetch('/start_control').catch(error => console.error('Error:', error));"));
  client.println(F("});"));
  
  client.println(F("document.addEventListener('mousemove', function(e) {"));
  client.println(F("  updateJoystick(e.clientX, e.clientY);"));
  client.println(F("});"));
  
  client.println(F("document.addEventListener('mouseup', function(e) {"));
  client.println(F("  if (isDragging) {"));
  client.println(F("    isDragging = false;"));
  client.println(F("    resetJoystick();"));
  client.println(F("    fetch('/stop_control').catch(error => console.error('Error:', error));"));
  client.println(F("  }"));
  client.println(F("});"));
  
  client.println(F("document.addEventListener('mouseleave', function(e) {"));
  client.println(F("  if (isDragging) {"));
  client.println(F("    isDragging = false;"));
  client.println(F("    resetJoystick();"));
  client.println(F("    fetch('/stop_control').catch(error => console.error('Error:', error));"));
  client.println(F("  }"));
  client.println(F("});"));
  
  // Touch Events
  client.println(F("joystickKnob.addEventListener('touchstart', function(e) {"));
  client.println(F("  isDragging = true; initJoystick(); e.preventDefault();"));
  client.println(F("  fetch('/start_control').catch(error => console.error('Error:', error));"));
  client.println(F("});"));
  
  client.println(F("document.addEventListener('touchmove', function(e) {"));
  client.println(F("  if (e.touches.length > 0) {"));
  client.println(F("    updateJoystick(e.touches[0].clientX, e.touches[0].clientY);"));
  client.println(F("  }"));
  client.println(F("  e.preventDefault();"));
  client.println(F("});"));
  
  client.println(F("document.addEventListener('touchend', function(e) {"));
  client.println(F("  if (isDragging) {"));
  client.println(F("    isDragging = false;"));
  client.println(F("    resetJoystick();"));
  client.println(F("    fetch('/stop_control').catch(error => console.error('Error:', error));"));
  client.println(F("  }"));
  client.println(F("});"));
  
  client.println(F("document.addEventListener('touchcancel', function(e) {"));
  client.println(F("  if (isDragging) {"));
  client.println(F("    isDragging = false;"));
  client.println(F("    resetJoystick();"));
  client.println(F("    fetch('/stop_control').catch(error => console.error('Error:', error));"));
  client.println(F("  }"));
  client.println(F("});"));
  
  client.println(F("function startHeartbeat() {"));
  client.println(F("  heartbeatInterval = setInterval(function() {"));
  client.println(F("    if (!isDragging) {"));
  client.println(F("      fetch('/heartbeat').catch(error => console.error('Heartbeat error:', error));"));
  client.println(F("    }"));
  client.println(F("  }, 5000);"));
  client.println(F("}"));
  
  client.println(F("window.addEventListener('load', initJoystick);"));
  client.println(F("window.addEventListener('resize', initJoystick);"));
  client.println(F("updateSensorData();"));
  client.println(F("setInterval(updateSensorData, 300);"));
  client.println(F("startHeartbeat();"));
  client.println(F("</script>"));
  
  client.println(F("</body>"));
  client.println(F("</html>"));
}
    protected:
};
#endif