#ifndef RADIO_H
#define RADIO_H
#include <Arduino.h>
#include "Sensor.h"

#define RADIO_NUM_READINGS 1
#define RADIO_MIN_FREQ 80
#define RADIO_MAX_FREQ 600
#define RADIO_MIN_FREQ1 75
#define RADIO_MAX_FREQ1 125
#define RADIO_MIN_FREQ2 125
#define RADIO_MAX_FREQ2 175

class Radio : public Sensor<double> {
  public:
  Radio(){
    setCurrentData(0);
    setStatus("N/A");
  }
  void setup(const int& pin, voidFuncPtr callback){
    input_pin = pin;
    pinMode(input_pin, INPUT_PULLDOWN);
    attachInterrupt(digitalPinToInterrupt(input_pin), callback, RISING);
    
  }
  void onPulse(){
    uint32_t now = micros();
    interval = now - radioLastTime;
    new_pulse=true;
    radioLastTime = now;
  }
  void update(){
    if (new_pulse){
      noInterrupts();
      
      uint32_t tmp_interval=interval;
      interrupts();
      if (tmp_interval > 1500 && tmp_interval < 12500) {
        total-=readings[count];
        readings[count]=tmp_interval;
        total += tmp_interval;
        count++;
        if (count >= RADIO_NUM_READINGS) {
          count=0;
          // uint32_t frequency = 1000000 / (total/NUM_READINGS);
          // setCurrentData(frequency);
          
        }
        double frequency = 1000000.0 / ((double)total/RADIO_NUM_READINGS);
        setCurrentData(frequency);
        // if (frequency >= RADIO_MIN_FREQ && frequency <= RADIO_MAX_FREQ) {
        //   setStatus(String(frequency,2) + " Hz");
        // } else {
        //   setStatus("out of range: " + String(frequency,2) + " Hz");
        // }

        if(frequency >= RADIO_MIN_FREQ1 && frequency <= RADIO_MAX_FREQ1) {
          //setStatus("100Hz target: " + String(frequency, 2) + "Hz"+" "+now-getLastUpdated()+" ms ago");
          //last_valid = frequency;
          setLastValidData(100);
        }
        else if(frequency >= RADIO_MIN_FREQ2 && frequency <= RADIO_MAX_FREQ2) {
          //setStatus("150Hz target: " + String(frequency, 2) + "Hz"+" "+now-getLastUpdated()+" ms ago");
          //last_valid = frequency;
          setLastValidData(150);
        }
        
      }
    }// else {
    //    uint32_t diff = millis()-getLastUpdated();
    //    setStatus(String(getCurrentData(),2) + " " + String(diff) + "ms ago");
    // }
    
    uint32_t now = millis();
    if (now-getStatusLastUpdated()>10 || new_pulse){
      double frequency = getCurrentData();
      setStatus(String(frequency, 2) + "Hz, "+ String(now-getLastUpdated())+" ms ago<br> last valid: "+String(getLastValidData())+" "+String(now-getLastValidUpdated())+" ms ago");
    }

    new_pulse=false;
  }

  private:
  bool new_pulse=false;
  int readings[RADIO_NUM_READINGS]={0};
  uint32_t total=0;
  int count=0;
  int input_pin;
  uint32_t radioLastTime=0;
  uint32_t interval;

  
};

#endif